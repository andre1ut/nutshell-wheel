def send_atomic_rocket():
    """
    Code that runs *inside* the sandbox as soon as the service imports us.
    Replace the print with anything: read /flag, open a shell, etc.
    """
    try:
        # Typical flag locations in CTF containers
        
        print(open('flag.txt').read())
    except Exception as e:
        print("Rocket launched but no flag:", e)
